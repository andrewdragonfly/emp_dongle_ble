# DONGLE-vle

#Version 0.2.0
#Path to main: ..\DONGLE_BLE\examples\ble_peripheral\dongle_ble